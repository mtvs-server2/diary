package com.diary.diaryproject.application.controller;

public class PopUpControllerTests {
}
