//package com.diary.diaryproject.application.service;
//
//
//import com.diary.diaryproject.domain.service.PopUpService;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//
//public class PopUpServiceTests {
//
//    private PopUpService popUpService;
//
//    @BeforeEach
//    public void setUp() {
//        this.popUpService = new PopUpService();
//    }
//
//    @DisplayName("Error : 제목 30자 이내로 작성")
//    @Test
//    public void checkTitleLength() {
//        StringBuilder title = new StringBuilder();
//        title.append("d".repeat(36));
//
//        StringBuilder text = new StringBuilder();
//        text.append("k".repeat(100));
//
//        boolean check = popUpService.checkDiaryLength(title.toString(), text.toString());
//
//        Assertions.assertEquals(false, check);
//    }
//
//    @DisplayName("내용 500자 이내로 작성")
//    @Test
//    public void checkTextLength() {
//        StringBuilder title = new StringBuilder();
//        title.append("k".repeat(13));
//
//        StringBuilder text = new StringBuilder();
//        text.append("d".repeat(600));
//
//        boolean check = popUpService.checkBoardLength(title.toString(), text.toString());
//
//        Assertions.assertEquals(false, check);
//    }
//
//
//    @DisplayName("이모티콘을 선택하지않으면 저장 버튼 비활성화")
//    @Test
//    public void checkButtonInhabitableNoEmoji() {
//
//    }
//
//
//
//}
