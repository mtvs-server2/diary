package com.diary.diaryproject.domain.view;

public class View {
}
