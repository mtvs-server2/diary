package com.diary.diaryproject.domain.aggregate.enumtype;

public enum EmojiEnum {
    HAPPY,
    SMILE,
    ANGRY,
    CRY,
    CYNICAL
}
