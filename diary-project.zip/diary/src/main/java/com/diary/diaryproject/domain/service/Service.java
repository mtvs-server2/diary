package com.diary.diaryproject.domain.service;

public class Service {
}
