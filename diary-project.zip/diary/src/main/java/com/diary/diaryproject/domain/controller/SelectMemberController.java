package com.diary.diaryproject.domain.controller;

public class SelectMemberController {
}
