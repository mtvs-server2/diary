package com.diary.diaryproject.domain.dto;

public class DTO {
}
